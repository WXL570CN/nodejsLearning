#  安装nodemon自动重启程序
<hr>
## 安装方式
``
npm i --global nodemon
``

## 启动node.js程序就可以直接
``
nodemon  file.js
``

## 这样启动后改变node.js文件后 nodemon会自动帮助我们重启
