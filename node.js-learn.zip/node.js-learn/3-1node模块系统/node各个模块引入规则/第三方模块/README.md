#  第三方加载方式
1.首先会找npm下的对应模块的package.json 然后加载package.json的main所对应的文件

2.也就是说最终加载的就是main所对应的文件
