console.log('require a');
require('./b');
