console.log('model2 is start');

var number=200;

function say(){
  console.log('my is m2');
}
