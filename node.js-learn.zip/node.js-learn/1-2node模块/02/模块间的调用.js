//必须加./
console.log('model is start');
require('./m2');
console.log('model is end');
