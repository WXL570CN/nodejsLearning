console.log('model2 is start');

exports.name='Jerry';//export导出,目前可以理解成this

exports.say=function(){
  console.log('hello my is Jerry');
}
