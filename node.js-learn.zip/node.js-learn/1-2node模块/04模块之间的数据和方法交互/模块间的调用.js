//必须加./
console.log('model is start');
var m2=require('./m2');

//调用
console.log(m2.name);
console.log(m2.say());
